package com.shixin.listener;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.logging.Logger;

@WebListener

public class RequestLoggingListener  implements ServletRequestListener {
    private static final Logger logger = Logger.getLogger(RequestLoggingListener.class.getName());

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        LocalDateTime requestTime = LocalDateTime.now();
        request.setAttribute("requestTime", requestTime);

        //获取请求信息
        String clientIp = request.getRemoteAddr();
        String method = request.getMethod();
        String requestUri = request.getRequestURI();
        String queryString = request.getQueryString();
        String userAgent = request.getHeader("User-Agent");

        //记录日志
        logger.info(String.format("RequestInit: time=%s, ip=%s, method=%s, uri=%s, query=%s, user-agent=%s",
                requestTime, clientIp, method, requestUri, queryString, userAgent));
    }


    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        LocalDateTime requestTime = (LocalDateTime) request.getAttribute("requestTime");
        LocalDateTime responseTime = LocalDateTime.now();

        // 计算处理时间
        Duration duration = Duration.between(requestTime, responseTime);

        //j=记录日志，请求处理的时间
        logger.info(String.format("RequestComplete: completeTime=%d ms", duration.toMillis()));
    }
}
