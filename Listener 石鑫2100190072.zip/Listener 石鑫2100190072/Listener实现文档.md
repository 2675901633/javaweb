## RequestLoggingListener 实现说明

### 概述
实现基于 `ServletRequestListener` 接口，目的是记录每个 HTTP 请求的详细信息，包括请求的开始时间、客户端 IP 地址、请求方法、请求 URI、查询字符串、`User-Agent` 信息，以及请求处理的时间。

我们使用 `System.out.println()` 输出日志信息，并在请求开始和结束时进行时间计算。所有日志信息都会显示在服务器的控制台中。

---

### 实现步骤

1. **实现 `ServletRequestListener` 接口**
   - `requestInitialized(ServletRequestEvent sre)`：用于在每个请求到达时获取请求信息并记录开始时间。
   - `requestDestroyed(ServletRequestEvent sre)`：在请求完成后计算处理时间并输出相关日志。

2. **日志信息**
   - 在请求初始化时，记录以下信息：
     - 请求时间
     - 客户端 IP 地址
     - 请求方法（如 `GET`、`POST` 等）
     - 请求 URI
     - 查询字符串（如果有）
     - `User-Agent`
     
   - 在请求完成时，计算并记录请求的处理时间。

---

### 代码说明

#### 1. `requestInitialized()` 方法
此方法在每个请求到达时触发：
- **步骤**：
  - 获取请求的详细信息（如 IP 地址、URI、方法等）。
  - 使用 `LocalDateTime.now()` 获取当前请求时间，并将其存储到请求的属性中，便于在 `requestDestroyed()` 方法中使用。
  - 使用 `System.out.println()` 输出初始化日志。

#### 2. `requestDestroyed()` 方法
此方法在每个请求结束时触发：
- **步骤**：
  - 从请求中获取请求开始时间，并使用 `LocalDateTime.now()` 获取响应结束时间。
  - 使用 `Duration.between()` 方法计算请求的处理时间。
  - 使用 `System.out.println()` 输出请求处理完成时间（以毫秒为单位）。

---

### 注意事项
- **时间计算**：使用 `java.time.LocalDateTime` 和 `java.time.Duration` 进行时间的记录和处理，确保精确计算请求的处理时间。为了避免格式化错误，使用 `duration.toMillis()` 将处理时间转换为毫秒并输出。
  

---

