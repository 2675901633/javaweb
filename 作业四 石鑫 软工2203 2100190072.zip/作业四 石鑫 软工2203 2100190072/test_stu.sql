use student_management;


# 1. 查询所有学生的信息。
SELECT *
FROM student;

# 2. 查询所有课程的信息。
SELECT *
FROM course;

# 3. 查询所有学生的姓名、学号和班级。
SELECT name,student_id,my_class
FROM student;

# 4. 查询所有教师的姓名和职称。
SELECT name, title
FROM teacher;

# 5. 查询不同课程的平均分数。
SELECT course_id,avg(score)
FROM score
GROUP BY course_id;

# 6. 查询每个学生的平均分数。
SELECT s.name, AVG(sc.score) AS average_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name;


# 7. 查询分数大于85分的学生学号和课程号。
SELECT score.student_id,score.course_id
FROM score
WHERE score>85;

# 8. 查询每门课程的选课人数。
SELECT course_id,count(student_id)
FROM score
GROUP BY course_id ;

# 9. 查询选修了"高等数学"课程的学生姓名和分数。
SELECT s.name, sc.score
FROM student s
JOIN score sc ON sc.student_id = s.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE c.course_name = '高等数学';

# 10. 查询没有选修"大学物理"课程的学生姓名。
SELECT s.name
FROM student s
LEFT JOIN score sc ON s.student_id = sc.student_id
AND sc.course_id = (SELECT course_id FROM course WHERE course_name = '大学物理')
WHERE sc.score IS NULL;

# 11. 查询C001比C002课程成绩高的学生信息及课程分数。
WITH HighAchievers AS (
    SELECT sc1.student_id
    FROM score sc1
    JOIN score sc2 ON sc1.student_id = sc2.student_id
    AND sc1.course_id <> sc2.course_id
    WHERE sc1.course_id = 'C001' AND sc2.course_id = 'C002' AND sc1.score > sc2.score
)
SELECT s.*
FROM student s
JOIN HighAchievers sa ON s.student_id = sa.student_id;

# 12. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比
# SELECT
#     course_id,
#     course_name,
#     COUNT(CASE WHEN score BETWEEN 85 AND 100 THEN 1 END) AS "[100-85]",
#     COUNT(CASE WHEN score BETWEEN 70 AND 84 THEN 1 END) AS "[85-70]",
#     COUNT(CASE WHEN score BETWEEN 60 AND 69 THEN 1 END) AS "[70-60]",
#     COUNT(CASE WHEN score < 60 THEN 1 END) AS "[60-0]",
#     COUNT(CASE WHEN score BETWEEN 85 AND 100 THEN 1 END) / COUNT(*) * 100 AS "Percentage [100-85]",
#     COUNT(CASE WHEN score BETWEEN 70 AND 84 THEN 1 END) / COUNT(*) * 100 AS "Percentage [85-70]",
#     COUNT(CASE WHEN score BETWEEN 60 AND 69 THEN 1 END) / COUNT(*) * 100 AS "Percentage [70-60]",
#     COUNT(CASE WHEN score < 60 THEN 1 END) / COUNT(*) * 100 AS "Percentage [60-0]"
# FROM
#     score
# GROUP BY
#     course_id,
#     course_name;

# 13. 查询选择C002课程但没选择C004课程的成绩情况(不存在时显示为 null )。
SELECT s.name, c.course_name,sc.score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE c.course_id = 'C002'
AND s.student_id NOT IN (SELECT student_id FROM score WHERE course_id = 'C004');

# 14. 查询平均分数最高的学生姓名和平均分数。
WITH avgScore AS (
    SELECT s.name, AVG(sc.score) AS average_score
    FROM student s
    JOIN score sc ON s.student_id = sc.student_id
    GROUP BY s.name
)
SELECT name, average_score
FROM avgScore
WHERE average_score = (
    SELECT MAX(average_score) FROM avgScore
);

# 15. 查询总分最高的前三名学生的姓名和总分。
WITH sunScore AS (SELECT student.name, SUM(score) ss
                  FROM score
                           JOIN student ON score.student_id = student.student_id
                           GROUP BY student.name
                           )
SELECT name,ss
FROM sunScore
ORDER BY ss DESC
LIMIT 3;



# 16. 查询各科成绩最高分、最低分和平均分。要求如下：
# 以如下形式显示：课程 ID，课程 name，最高分，最低分，平均分，及格率，中等率，优良率，优秀率
# 及格为>=60，中等为：70-80，优良为：80-90，优秀为：>=90
# 要求输出课程号和选修人数，查询结果按人数降序排列，若人数相同，按课程号升序排列


# 17. 查询男生和女生的人数。
SELECT count('男') 男生人数, count('女') 女生人数
FROM student;

# 18. 查询年龄最大的学生姓名。
SELECT student.name,birth_date
FROM student
WHERE birth_date = (
    SELECT min(birth_date)
    FROM student
);

# 19. 查询年龄最小的教师姓名。
SELECT teacher.name,birth_date
FROM teacher
WHERE birth_date = (
    SELECT max(birth_date)
    FROM teacher
);

# 20. 查询学过「张教授」授课的同学的信息。
  SELECT score.student_id
    FROM student
    JOIN score ON student.student_id = score.student_id
    JOIN course ON score.course_id = course.course_id
    JOIN teacher ON course.teacher_id = teacher.teacher_id
    WHERE teacher.name='张教授';

# 21. 查询查询至少有一门课与学号为"2021001"的同学所学相同的同学的信息 。
SELECT DISTINCT student.*
FROM student
JOIN score ON student.student_id = score.student_id
WHERE course_id IN (
    SELECT course_id
    FROM score
    WHERE score.student_id='2021001'
);

# 22. 查询每门课程的平均分数，并按平均分数降序排列。
SELECT score.course_id, avg(score.score) avgScore
FROM score
GROUP BY course_id
ORDER BY avg(score) DESC ;

# 23. 查询学号为"2021001"的学生所有课程的分数。
SELECT score.student_id,course_id,score.score
FROM score
WHERE student_id='2021001';

# 24. 查询所有学生的姓名、选修的课程名称和分数。
SELECT student.name,course.course_name,score.score
FROM score
JOIN student ON score.student_id = student.student_id
JOIN course ON score.course_id = course.course_id;

# 25. 查询每个教师所教授课程的平均分数。
SELECT teacher.name,avg(score.score) avgScore
FROM course
JOIN teacher ON course.teacher_id = teacher.teacher_id
JOIN score ON course.course_id = score.course_id
GROUP BY teacher.name;

# 26. 查询分数在80到90之间的学生姓名和课程名称。
SELECT student.name,course.course_name
FROM score
JOIN student ON score.student_id = student.student_id
JOIN course ON score.course_id = course.course_id
WHERE score BETWEEN 80 AND 90;

# 27. 查询每个班级的平均分数。
SELECT my_class,avg(score.score)
FROM score
JOIN course ON score.course_id = course.course_id
JOIN student ON score.student_id = student.student_id
GROUP BY my_class;


# 28. 查询没学过"王讲师"老师讲授的任一门课程的学生姓名。
SELECT DISTINCT student.name
FROM score
JOIN student ON score.student_id = student.student_id
JOIN course ON score.course_id = course.course_id
WHERE score.course_id NOT IN (
    SELECT score.course_id
    FROM score
    JOIN course ON score.course_id = course.course_id
    JOIN teacher ON course.teacher_id = teacher.teacher_id
    WHERE teacher.name='王讲师'
);

# 29. 查询两门及其以上小于85分的同学的学号，姓名及其平均成绩 。
SELECT score.student_id, student.name, avg(score.score) avgscore
FROM score
JOIN student ON score.student_id = student.student_id
GROUP BY score.student_id, student.name
HAVING sum(if(score>85,1,0)) >= 2;

# 30. 查询所有学生的总分并按降序排列。
SELECT score.student_id,sum(score.score) totalscore
FROM score
GROUP BY student_id
ORDER BY totalscore DESC ;

# 31. 查询平均分数超过85分的课程名称。
SELECT course.course_name, avg(score.score) avgscore
FROM score
JOIN course ON score.course_id = course.course_id
GROUP BY course.course_name
HAVING avgscore > 85;

# 32. 查询每个学生的平均成绩排名。
SELECT student.name,avg(score.score) avgscore,
rank() OVER (
 ORDER BY avg(score.score) DESC
) AS avgscore_rank
from score
JOIN student ON score.student_id = student.student_id
GROUP BY student.name;

# 33. 查询每门课程分数最高的学生姓名和分数。
SELECT name, s1.score
FROM score s1
JOIN  student ON s1.student_id = student.student_id
WHERE s1.score = (
        SELECT MAX(s2.score)
        FROM score s2
        WHERE s2.course_id = s1.course_id
    );

# 34. 查询选修了"高等数学"和"大学物理"的学生姓名。
SELECT s.name
FROM student s
JOIN score sc1 ON s.student_id = sc1.student_id
JOIN score sc2 ON s.student_id = sc2.student_id
WHERE sc1.course_id = 'C001' AND sc2.course_id = 'C002';


# 35. 按平均成绩从高到低显示所有学生的所有课程的成绩以及平均成绩（没有选课则为空）。
SELECT s.name, c.course_name, sc.score, AVG(sc.score) OVER (PARTITION BY s.student_id) AS avg_score
FROM student s
LEFT JOIN score sc ON s.student_id = sc.student_id
LEFT JOIN course c ON sc.course_id = c.course_id
ORDER BY avg_score DESC;


# 36. 查询分数最高和最低的学生姓名及其分数。
SELECT s.name, sc.score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.score = (SELECT MAX(score) FROM score)
   OR sc.score = (SELECT MIN(score) FROM score);

# 37. 查询每个班级的最高分和最低分。
SELECT s.my_class, MAX(sc.score) AS max_score, MIN(sc.score) AS min_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.my_class;

# 38. 查询每门课程的优秀率（优秀为90分）。
SELECT c.course_name,
       COUNT(CASE WHEN sc.score >= 90 THEN 1 END) / COUNT(*) * 100 AS excellent_rate
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_name;

# 39. 查询平均分数超过班级平均分数的学生。
WITH class_avg AS (
    SELECT s.my_class, AVG(sc.score) AS avg_score
    FROM student s
    JOIN score sc ON s.student_id = sc.student_id
    GROUP BY s.my_class
)
SELECT s.name, sc.score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN class_avg ca ON s.my_class = ca.my_class
WHERE sc.score > ca.avg_score;

# 40. 查询每个学生的分数及其与课程平均分的差值。
SELECT s.name, c.course_name, sc.score,
       sc.score - AVG(sc.score) OVER (PARTITION BY sc.course_id) AS score_diff
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id;
