use employee_management;

SELECT *
FROM employees;

# 1. 查询所有员工的姓名、邮箱和工作岗位。
SELECT first_name, last_name, email, job_title
FROM employees;

# 2. 查询所有部门的名称和位置。
select dept_name, location
from departments;

# 3. 查询工资超过70000的员工姓名和工资。
select first_name,last_name,salary
from employees
where salary >= 70000;

# 4. 查询IT部门的所有员工。
select employees.first_name, employees.last_name, dept_name
from employees ,departments
where dept_name = 'IT' and employees.dept_id=departments.dept_id;

# 5. 查询入职日期在2020年之后的员工信息。
select employees.*
from employee_projects
join projects on employee_projects.project_id = projects.project_id
join employees on employee_projects.emp_id = employees.emp_id
where start_date > 2020;

# 6. 计算每个部门的平均工资。
select avg(employees.salary) avgsalary,dept_name
from employees
JOIN employee_management.departments d ON employees.dept_id = d.dept_id
GROUP BY d.dept_id;

# 7. 查询工资最高的前3名员工信息。
SELECT employees.*
FROM employees
ORDER BY salary DESC
LIMIT 3;

# 8. 查询每个部门员工数量。
SELECT count(employees.emp_id),dept_id
FROM employees
GROUP BY dept_id;

# 9. 查询没有分配部门的员工。
SELECT employees.emp_id
FROM employees
WHERE dept_id IS NULL;

# 10. 查询参与项目数量最多的员工。
WITH employees_count_project_id AS (
    SELECT
        employees.emp_id,
        COUNT(employee_projects.project_id) AS project_count
    FROM
        employees
    JOIN
        employee_projects ON employees.emp_id = employee_projects.emp_id
    GROUP BY
        employees.emp_id
)
SELECT *
FROM
    employees_count_project_id
WHERE
    project_count = (
        SELECT MAX(project_count)
        FROM employees_count_project_id
    );

# 11. 计算所有员工的工资总和。
SELECT sum(employees.salary) totalSalary
FROM employees;

# 12. 查询姓"Smith"的员工信息。
SELECT *
FROM employees
WHERE last_name='Smith';

# 13. 查询即将在半年内到期的项目。
SELECT project_name
FROM projects
WHERE DATEDIFF(end_date, CURDATE()) BETWEEN 0 AND 180;

# 14. 查询至少参与了两个项目的员工。
SELECT emp_id, COUNT(project_id) AS project_count
FROM employee_projects
GROUP BY emp_id
HAVING COUNT(project_id) > 1;

# 15. 查询没有参与任何项目的员工。
SELECT emp_id, first_name, last_name
FROM employees
WHERE emp_id NOT IN (
    SELECT emp_id
    FROM employee_projects
);

# 16. 计算每个项目参与的员工数量。
SELECT count(emp_id), project_id
FROM employee_projects
GROUP BY project_id;

# 17. 查询工资第二高的员工信息。
SELECT *
FROM employees
WHERE salary = (
    SELECT MAX(salary)
    FROM employees
    WHERE salary < (SELECT MAX(salary) FROM employees)
);


# 18. 查询每个部门工资最高的员工。
SELECT *
FROM employees e1
WHERE (e1.dept_id, e1.salary) IN (
    SELECT dept_id, MAX(salary)
    FROM employees
    GROUP BY dept_id
);

# 19. 计算每个部门的工资总和,并按照工资总和降序排列。
SELECT sum(employees.salary), dept_id
FROM employees
GROUP BY dept_id
ORDER BY sum(employees.salary) DESC ;

# 20. 查询员工姓名、部门名称和工资。
SELECT employees.first_name,employees.last_name,departments.dept_name,employees.salary
FROM employees
JOIN departments ON employees.dept_id = departments.dept_id;

# 21. 查询每个员工的上级主管(假设emp_id小的是上级)。


# 22. 查询所有员工的工作岗位,不要重复。
SELECT DISTINCT job_title
FROM employees;

# 23. 查询平均工资最高的部门。
SELECT dept_id, AVG(salary) AS avgSalary
FROM employees
GROUP BY dept_id
HAVING AVG(salary) = (
    SELECT MAX(avgSalary)
    FROM (
        SELECT AVG(salary) AS avgSalary
        FROM employees
        GROUP BY dept_id
    ) AS subquery
);

# 24. 查询工资高于其所在部门平均工资的员工。
WITH DepartmentAvgSalary AS (
    SELECT employees.dept_id,avg(employees.salary) avgsalary
    FROM employees
    GROUP BY dept_id
 )

SELECT *
FROM DepartmentAvgSalary das
JOIN employees ON das.dept_id=employees.dept_id
WHERE das.dept_id=employees.dept_id and salary>avgsalary;


# 26. 查询跨部门的项目(参与员工来自不同部门)。
SELECT ep.project_id
FROM employee_projects ep
JOIN employees e ON ep.emp_id = e.emp_id
GROUP BY ep.project_id
HAVING COUNT(DISTINCT e.dept_id) > 1;



