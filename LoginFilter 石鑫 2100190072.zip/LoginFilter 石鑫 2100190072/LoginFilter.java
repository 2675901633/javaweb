package com.shixin.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

// 登录验证过滤器
@WebFilter("/*") // 过滤器将拦截所有请求
public class LoginFilter implements Filter {
    // 定义不需要进行登录验证的路径
    private List<String> excludePaths = Arrays.asList("/register", "/public", "/login", "/login.jsp", "/html", "/js", "/css", "/Filter/login");

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        // 获取当前请求的 URI
        String requestURI = req.getRequestURI();

        // 检查当前请求是否在排除列表中
        if (isExcluded(requestURI)) {
            // 如果在排除列表中，直接继续处理请求
            chain.doFilter(request, response);
        } else {
            // 检查用户是否已登录
            if (req.getSession().getAttribute("user") != null) {
                // 如果已登录，继续处理请求
                chain.doFilter(request, response);
            } else {
                // 用户未登录，重定向到登录页面
                res.sendRedirect(req.getContextPath() + "/login.jsp");
            }
        }
    }

    @Override
    public void destroy() {
        // 在过滤器销毁时执行清理工作
    }

    // 检查请求 URI 是否在排除路径列表中
    private boolean isExcluded(String requestURI) {
        for (String path : excludePaths) {
            // 如果请求 URI 等于排除路径，或者请求 URI 以排除路径开头（例如子路径），返回 true
            if (requestURI.equals(path) || requestURI.startsWith(path + "/")) {
                return true;
            }
        }
        // 如果不在排除列表中，返回 false
        return false;
    }
}
