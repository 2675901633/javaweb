# LoginFilter 实现文档

## 1. 概述

`LoginFilter` 是一个用于处理用户登录状态的 Servlet 过滤器。它拦截所有进入的请求，并根据用户的登录状态决定是否允许访问特定资源。

## 2. 功能

- **请求拦截**：拦截所有请求，通过 URL 模式 `/*` 实现。
- **登录状态检查**：检查用户是否已登录，如果已登录，允许访问请求资源；如果未登录，重定向到登录页面。
- **排除路径**：对某些路径（如登录页和公共资源）进行排除，避免过滤器干扰这些请求。

## 3. 实现细节

### 3.1 主要组件

- **排除路径列表**：指定不需要进行登录验证的路径，包括：
  - `/register`：注册页面
  - `/public`：公共资源
  - `/login`：登录处理路径
  - `/login.jsp`：登录页面
  - `/html`、`/js`、`/css`：静态资源

### 3.2 主要方法

- **init(FilterConfig filterConfig)**：初始化过滤器，准备任何必要的资源（当前未使用）。

- **doFilter(ServletRequest request, ServletResponse response, FilterChain chain)**：
  - 获取请求 URI。
  - 检查请求是否在排除列表中：
    - 如果在排除列表中，继续处理请求。
    - 如果不在排除列表中，检查用户的登录状态：
      - 如果已登录，继续处理请求。
      - 如果未登录，重定向到登录页面。

- **destroy()**：清理资源（当前未使用）。

- **isExcluded(String requestURI)**：判断请求 URI 是否在排除路径列表中，支持子路径检查。

  

## 4. 注意事项

- 确保路径列表的配置正确，避免引起重定向循环。
- 在处理静态资源时，应根据需要调整排除路径，确保应用的性能和安全性。

## 5. 示例

以下是 `LoginFilter` 的代码示例：

```java
@WebFilter("/*")
public class LoginFilter implements Filter {
    private List<String> excludePaths = Arrays.asList(
        "/register",
        "/public",
        "/login",
        "/login.jsp",
        "/html",
        "/js",
        "/css"
    );

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 初始化逻辑
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String requestURI = req.getRequestURI();

        if (isExcluded(requestURI)) {
            chain.doFilter(request, response);
        } else {
            if (req.getSession().getAttribute("user") != null) {
                chain.doFilter(request, response);
            } else {
                res.sendRedirect(req.getContextPath() + "/login.jsp");
            }
        }
    }

    @Override
    public void destroy() {
        // 清理逻辑
    }

    private boolean isExcluded(String requestURI) {
        for (String path : excludePaths) {
            if (requestURI.equals(path) || requestURI.startsWith(path + "/")) {
                return true;
            }
        }
        return false;
    }
}
```
