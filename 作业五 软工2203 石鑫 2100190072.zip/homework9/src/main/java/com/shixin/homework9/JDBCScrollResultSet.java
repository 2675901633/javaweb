package com.shixin.homework9;



import java.sql.*;

public class JDBCScrollResultSet {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "SELECT * FROM teacher";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = ps.executeQuery()) {

            rs.absolute(-2);
            System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}