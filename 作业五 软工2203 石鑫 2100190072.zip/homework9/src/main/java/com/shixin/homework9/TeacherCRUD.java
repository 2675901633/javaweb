package com.shixin.homework9;

import java.sql.*;

public class TeacherCRUD {

    private static final String URL = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
    private static final String USER = "root";
    private static final String PASSWORD = "sx2002411";

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        // Create: Insert a new teacher into the teacher table
        String insertSQL = "INSERT INTO teacher (name, course, birthday) VALUES (?, ?, ?)";
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            ps = conn.prepareStatement(insertSQL);
            ps.setString(1, "李四");
            ps.setString(2, "化学");
            ps.setDate(3, Date.valueOf("1992-05-15"));
            int rowsAffected = ps.executeUpdate();
            System.out.println("Insert: " + rowsAffected + " rows affected.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }

        // Read: Select all teachers from the teacher table
        String readSQL = "SELECT * FROM teacher";
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            ps = conn.prepareStatement(readSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("Read: Teacher ID = " + rs.getInt("id") + ", Name = " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, ps, conn);
        }

        // Update: Update the course of an existing teacher
        String updateSQL = "UPDATE teacher SET course = ? WHERE id = ?";
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            ps = conn.prepareStatement(updateSQL);
            ps.setString(1, "物理");
            ps.setInt(2, 1); // Assuming the ID of the teacher to update is 1
            int rowsAffected = ps.executeUpdate();
            System.out.println("Update: " + rowsAffected + " rows affected.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }

        // Delete: Delete a teacher from the teacher table
        String deleteSQL = "DELETE FROM teacher WHERE id = ?";
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            ps = conn.prepareStatement(deleteSQL);
            ps.setInt(1, 1); // Assuming the ID of the teacher to delete is 1
            int rowsAffected = ps.executeUpdate();
            System.out.println("Delete: " + rowsAffected + " rows affected.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }
    }

    private static void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}