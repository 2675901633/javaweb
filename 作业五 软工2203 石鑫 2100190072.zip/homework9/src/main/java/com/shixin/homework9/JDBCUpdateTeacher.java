package com.shixin.homework9;


import java.sql.*;

public class JDBCUpdateTeacher {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "UPDATE teacher SET course = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "物理");
            ps.setInt(2, 1); // 假设更新ID为1的教师
            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("更新成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}