package com.shixin.homework9;


import java.sql.*;

public class JDBCDeleteTeacher {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "DELETE FROM teacher WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, 1); // 假设删除ID为1的教师
            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("删除成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}