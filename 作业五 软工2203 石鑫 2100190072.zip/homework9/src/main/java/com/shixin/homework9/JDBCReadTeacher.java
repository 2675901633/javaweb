package com.shixin.homework9;

import java.sql.*;

public class JDBCReadTeacher {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "SELECT * FROM teacher";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", 姓名: " + rs.getString("name") + ", 课程: " + rs.getString("course") + ", 生日: " + rs.getDate("birthday"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}