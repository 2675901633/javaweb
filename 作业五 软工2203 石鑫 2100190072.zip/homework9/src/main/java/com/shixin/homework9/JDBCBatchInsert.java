//package com.shixin.homework9;
//
//
//import java.sql.*;
//
//public class JDBCBatchInsert {
//    public static void main(String[] args) {
//        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
//        String user = "root";
//        String password = "sx2002411";
//        String sql = "INSERT INTO teacher(name, course, birthday) VALUES(?,?,?)";
//
//        try (Connection conn = DriverManager.getConnection(url, user, password)) {
//            conn.setAutoCommit(false); // 关闭自动提交
//            try (PreparedStatement ps = conn.prepareStatement(sql)) {
//                for (int i = 1; i <= 500; i++) {
//                    ps.setString(1, "教师" + i);
//                    ps.setString(2, "课程" + i % 10);
//                    ps.setDate(3, Date.valueOf("2002-01-01"));
//                    ps.addBatch();
//                    if (i % 100 == 0) { // 每100条记录执行一次批处理
//                        ps.executeBatch();
//                        conn.commit();
//                        ps.clearBatch();
//                    }
//                }
//                ps.executeBatch(); // 执行剩余的批处理
//                conn.commit();
//                System.out.println("完成批量插入数据");
//            } catch (SQLException e) {
//                conn.rollback();
//                e.printStackTrace();
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//}

package com.shixin.homework9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.StringTokenizer;

public class JDBCBatchInsert {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "INSERT INTO teacher(name, course, birthday) VALUES(?,?,?)";
        String csvFilePath = "C:\\Users\\thinker\\Desktop\\teachers.csv";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(url, user, password);
            conn.setAutoCommit(false);

            try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
                ps = conn.prepareStatement(sql);
                String line;
                br.readLine(); // 跳过CSV头部
                int count = 0;
                while ((line = br.readLine()) != null) {
                    StringTokenizer tokenizer = new StringTokenizer(line, ",");
                    if (tokenizer.countTokens() == 3) {
                        String name = tokenizer.nextToken().trim();
                        String course = tokenizer.nextToken().trim();
                        String birthday = tokenizer.nextToken().trim();

                        ps.setString(1, name);
                        ps.setString(2, course);
                        ps.setDate(3, Date.valueOf(birthday));
                        ps.addBatch();

                        count++;
                        if (count % 100 == 0) {
                            ps.executeBatch();
                            conn.commit();
                            ps.clearBatch();
                        }
                    }
                }
                // 最后一批数据插入
                if (count % 100 != 0) {
                    ps.executeBatch();
                    conn.commit();
                }
                System.out.println("完成批量插入数据");
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}