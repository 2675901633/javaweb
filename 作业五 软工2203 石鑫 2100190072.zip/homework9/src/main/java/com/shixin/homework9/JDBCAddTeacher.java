package com.shixin.homework9;


import java.sql.*;

public class JDBCAddTeacher {
    public static void main(String[] args) {
        String url = "jdbc:mysql:///jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "sx2002411";
        String sql = "INSERT INTO teacher (name, course, birthday) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // 插入数据
            ps.setString(1, "张三");
            ps.setString(2, "数学");
            ps.setDate(3, Date.valueOf("2002-01-01"));
            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("插入成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}